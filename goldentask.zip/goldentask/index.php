<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Attendance System</h1>
        <form method="post">
            <label for="studentName">Student Name:</label>
            <input type="text" id="studentName" name="studentName" required>
            <button type="submit" name="markAttendance">Mark Attendance</button>
        </form>
        <h2>Attendance List</h2>
        <ul id="attendanceList">
            <?php
            // Check if the form is submitted
            if (isset($_POST['markAttendance'])) {
                $studentName = $_POST['studentName'];

                // Validate and sanitize the input (you can enhance validation)
                $studentName = filter_var($studentName, FILTER_SANITIZE_STRING);

                // Append the attendance data to the CSV file
                $attendanceFile = 'attendance.csv';
                $attendanceData = "$studentName, " . date('Y-m-d H:i:s') . PHP_EOL;
                file_put_contents($attendanceFile, $attendanceData, FILE_APPEND | LOCK_EX);
            }

            // Display attendance records from the CSV file
            $attendanceFile = 'attendance.csv';
            if (file_exists($attendanceFile)) {
                $attendanceData = file($attendanceFile, FILE_IGNORE_NEW_LINES);
                foreach ($attendanceData as $record) {
                    echo "<li>$record</li>";
                }
            }
            ?>
        </ul>
        <form method="post" action="download.php">
            <button type="submit" name="downloadCSV">Download CSV</button>
        </form>
    </div>
</body>
</html>
