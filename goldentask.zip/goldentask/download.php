<?php
if (isset($_POST['downloadCSV'])) {
    // Define the file name for the CSV file
    $fileName = 'attendance.csv';

    // Check if the file exists
    if (file_exists($fileName)) {
        // Set headers to force download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        header('Cache-Control: no-store, no-cache');

        // Read the file and output it to the browser
        readfile($fileName);
        exit;
    } else {
        // File does not exist, display an error message
        echo "The attendance CSV file does not exist.";
    }
}
?>
