<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the student name from the form
    $studentName = $_POST["studentName"];

    // Open a file to store attendance records (you can use a database for a real system)
    $file = fopen("attendance.csv", "a"); // Change "attendance.csv" to your desired file name

    if ($file) {
        // Write the student name and current date/time to the file
        $attendanceRecord = "$studentName, " . date("Y-m-d H:i:s") . "\n";
        fwrite($file, $attendanceRecord);

        // Close the file
        fclose($file);
    }
}

// Redirect back to the index page
header("Location: index.html");
?>
